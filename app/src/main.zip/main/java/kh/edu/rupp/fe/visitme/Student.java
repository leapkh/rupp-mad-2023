package kh.edu.rupp.fe.visitme;

public class Student {

    private void test(){

    }

}
